
------------------ 1. 插入data Excle doc C-H列  Q R列------------------

insert into test.manulife.Report1 (TAB,MAP_KEY,TRAN_NATURE,AV_TAG_STATUS_CODE,BANK_IN_DATE,PAY_AMT,RECEIPT_REF_NO,PAY_METHOD_CODE)
SELECT
    'CHU',
    MAP_KEY,
    TRAN_NATURE,
    AV_TAG_STATUS_CODE,
    FILE_DATE,
    PAY_AMT,
    RECEIPT_REF_NO,
    PAY_METHOD_CODE,
FROM
	test.manulife.From_CAS_CHQ 
order by 'CHU', FILE_DATE
	

	
------------------ 2.1. update data Excle doc I-P列 (1) SuspenseRecord 存在------------------

update R1
set r.LAST_DELTA_DATE = sr.LAST_DELTA_DATE,
r.DAYS_FOR_TAGGING  = DATEDIFF('day', sr.LAST_DELTA_DATE,BANK_IN_DATE ),
r.TAGGING_PERIOD= (
 CASE 
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 1 AND 7 
            THEN '1 - 7 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 8 AND 14 
            THEN '8 - 14 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 15 AND 21 
            THEN '15 - 21 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 22 AND 30 
            THEN '22 - 30 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 31 AND 60 
            THEN '31 - 60 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 61 AND 90 
            THEN '61 - 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) >= 91 
            THEN 'over 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) = 0 
            THEN '0 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) < 0 
            THEN 'Future date'
        ELSE 'Unknown'
    END
),
 r.RCVD_AMT = sr.RcvdAmt,
 r.AVAIL_AMT = sr.AvailAmt,
 r.TAGD_AMT = sr.TagdAmt,
 r.OVERPAID_AMT = sr.OverpaidAmt,
 r.VARIANCE = (r.PAY_AMT - sr.RcvdAmt)
 r.PaySubmitRefNo = sr.PaySubmitRefNo,

from manulife.Report1 r inner JOIN empf.SuspenseRecord sr 
on r.MAP_KEY = sr.PaySubmitRefNo 



------------------ 2.2. update data Excle doc I-P列  S—V(1) SuspenseRecord 不存在 ------------------
-select * from empf.PaymentDetails_V5 pdv 

update r
set r.LAST_DELTA_DATE = sr.LAST_DELTA_DATE,
r.DAYS_FOR_TAGGING  = DATEDIFF('day', sr.LAST_DELTA_DATE,BANK_IN_DATE ),
r.TAGGING_PERIOD= (
 CASE 
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 1 AND 7 
            THEN '1 - 7 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 8 AND 14 
            THEN '8 - 14 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 15 AND 21 
            THEN '15 - 21 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 22 AND 30 
            THEN '22 - 30 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 31 AND 60 
            THEN '31 - 60 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 61 AND 90 
            THEN '61 - 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) >= 91 
            THEN 'over 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) = 0 
            THEN '0 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) < 0 
            THEN 'Future date'
        ELSE 'Unknown'
    END
),
 r.RCVD_AMT = sr.RcvdAmt,
 r.AVAIL_AMT = sr.AvailAmt,
 r.TAGD_AMT = sr.TagdAmt,
 r.OVERPAID_AMT = sr.OverpaidAmt,
 r.VARIANCE = (r.PAY_AMT - sr.RcvdAmt)
 r.RCV_REF_NO = sr.RcvRefNo,
 r.PAY_SUBMIT_REF_NO = sr.PaySubmitRefNo,
 r.RCVD_AMT_2 = sr.RcvdAmt,
 r.STATUS_CD = sr.StatusCd,
 r.W = (r.PAY_AMT - pd.RcvdAmt)

from manulife.Report1 r inner JOIN empf.PaymentDetails pd 
on r.RECEIPT_REF_NO = pd.RcvRefNo
inner JOIN empf.SuspenseRecord sr 
on pd.PaySubmitRefNo = sr.PaySubmitRefNo 
where r.PD_PaySubmitRefNo is null



------------------ 3. update data Excle doc X列  ------------------


update r
set r.CAS_TOTAL =  sum_PAY_AMT
from manulife.Report1 r inner JOIN 
(select TAB, rp.BANK_IN_DATE , min(id)  id,SUM(rp.PAY_AMT ) sum_PAY_AMT from manulife.Report1 rp group by TAB, rp.BANK_IN_DATE ) gr
on r.id = gr.id





------------------ 4.1. update data Excle doc Y列  ------------------






------------------ 4.2. update data Excle doc AA列  ------------------



 



------------------ 4.3 update data Excle doc  Z  列  ------------------

update manulife.Report1  set VARIANCE_2 =  (CAS_TOTAL - BANK_STATEMENT)  





------------------ 4.3 update data Excle doc  AB列  ------------------

update manulife.Report1  set TOTAL_DAILY_VARIANCE =  (VARIANCE_2 + BANK_STATEMENT)  






ALTER TABLE test.manulife.Report1 ALTER COLUMN BANK_STATEMENT numeric(8,2) NULL;



CASE 
        WHEN t1.字段名 = t2.字段名 
             OR (t1.字段名 IS NULL AND t2.字段名 IS NULL)
        THEN '是' 
        ELSE '否' 
    END AS 是否相等

selec a1 , b1   (if a1!=b1) false,    (if a2!=b2) false,
from A  left join B  on A.id = B.id
where  a1!=b1  or a2!=b2 or 





------------------ 1. 插入data Excle doc C-H列  Q R列------------------

insert into test.manulife.Report1 (TAB,MAP_KEY,TRAN_NATURE,AV_TAG_STATUS_CODE,BANK_IN_DATE,PAY_AMT,RECEIPT_REF_NO,PAY_METHOD_CODE)
SELECT
    'CHU',
    MAP_KEY,
    TRAN_NATURE,
    AV_TAG_STATUS_CODE,
    FILE_DATE,
    PAY_AMT,
    RECEIPT_REF_NO,
    PAY_METHOD_CODE,
FROM
	test.manulife.From_CAS_CHQ 
order by 'CHU', FILE_DATE
	

	
------------------ 2.1. update data Excle doc I-P列 (1) SuspenseRecord 存在------------------

update R1
set r.LAST_DELTA_DATE = sr.LAST_DELTA_DATE,
r.DAYS_FOR_TAGGING  = DATEDIFF('day', sr.LAST_DELTA_DATE,BANK_IN_DATE ),
r.TAGGING_PERIOD= (
 CASE 
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 1 AND 7 
            THEN '1 - 7 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 8 AND 14 
            THEN '8 - 14 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 15 AND 21 
            THEN '15 - 21 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 22 AND 30 
            THEN '22 - 30 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 31 AND 60 
            THEN '31 - 60 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 61 AND 90 
            THEN '61 - 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) >= 91 
            THEN 'over 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) = 0 
            THEN '0 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) < 0 
            THEN 'Future date'
        ELSE 'Unknown'
    END
),
 r.RCVD_AMT = sr.RcvdAmt,
 r.AVAIL_AMT = sr.AvailAmt,
 r.TAGD_AMT = sr.TagdAmt,
 r.OVERPAID_AMT = sr.OverpaidAmt,
 r.VARIANCE = (r.PAY_AMT - sr.RcvdAmt)
 r.PaySubmitRefNo = sr.PaySubmitRefNo,

from manulife.Report1 r inner JOIN empf.SuspenseRecord sr 
on r.MAP_KEY = sr.PaySubmitRefNo 



------------------ 2.2. update data Excle doc I-P列  S—V(1) SuspenseRecord 不存在 ------------------
-select * from empf.PaymentDetails_V5 pdv 

update r
set r.LAST_DELTA_DATE = sr.LAST_DELTA_DATE,
r.DAYS_FOR_TAGGING  = DATEDIFF('day', sr.LAST_DELTA_DATE,BANK_IN_DATE ),
r.TAGGING_PERIOD= (
 CASE 
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 1 AND 7 
            THEN '1 - 7 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 8 AND 14 
            THEN '8 - 14 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 15 AND 21 
            THEN '15 - 21 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 22 AND 30 
            THEN '22 - 30 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 31 AND 60 
            THEN '31 - 60 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) BETWEEN 61 AND 90 
            THEN '61 - 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) >= 91 
            THEN 'over 90 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) = 0 
            THEN '0 days'
        WHEN DATEDIFF(DAY, TRY_CONVERT(sr.LAST_DELTA_DATE, BANK_IN_DATE), TRY_CONVERT(sr.LAST_DELTA_DATE, LAST_DELTA_DATE)) < 0 
            THEN 'Future date'
        ELSE 'Unknown'
    END
),
 r.RCVD_AMT = sr.RcvdAmt,
 r.AVAIL_AMT = sr.AvailAmt,
 r.TAGD_AMT = sr.TagdAmt,
 r.OVERPAID_AMT = sr.OverpaidAmt,
 r.VARIANCE = (r.PAY_AMT - sr.RcvdAmt)
 r.RCV_REF_NO = sr.RcvRefNo,
 r.PAY_SUBMIT_REF_NO = sr.PaySubmitRefNo,
 r.RCVD_AMT_2 = sr.RcvdAmt,
 r.STATUS_CD = sr.StatusCd,
 r.W = (r.PAY_AMT - pd.RcvdAmt)

from manulife.Report1 r inner JOIN empf.PaymentDetails pd 
on r.RECEIPT_REF_NO = pd.RcvRefNo
inner JOIN empf.SuspenseRecord sr 
on pd.PaySubmitRefNo = sr.PaySubmitRefNo 
where r.PD_PaySubmitRefNo is null



------------------ 3. update data Excle doc X列  ------------------


update r
set r.CAS_TOTAL =  sum_PAY_AMT
from manulife.Report1 r inner JOIN 
(select TAB, rp.BANK_IN_DATE , min(id)  id,SUM(rp.PAY_AMT ) sum_PAY_AMT from manulife.Report1 rp group by TAB, rp.BANK_IN_DATE ) gr
on r.id = gr.id





------------------ 4.1. update data Excle doc Y列  ------------------






------------------ 4.2. update data Excle doc AA列  ------------------



 



------------------ 4.3 update data Excle doc  Z  列  ------------------

update manulife.Report1  set VARIANCE_2 =  (CAS_TOTAL - BANK_STATEMENT)  





------------------ 4.3 update data Excle doc  AB列  ------------------

update manulife.Report1  set TOTAL_DAILY_VARIANCE =  (VARIANCE_2 + BANK_STATEMENT)  






ALTER TABLE test.manulife.Report1 ALTER COLUMN BANK_STATEMENT numeric(8,2) NULL;



CASE 
        WHEN t1.字段名 = t2.字段名 
             OR (t1.字段名 IS NULL AND t2.字段名 IS NULL)
        THEN '是' 
        ELSE '否' 
    END AS 是否相等

selec a1 , b1   (if a1!=b1) false,    (if a2!=b2) false,
from A  left join B  on A.id = B.id
where  a1!=b1  or a2!=b2 or 




